module BrabusStress
  class Scenario
  end
end