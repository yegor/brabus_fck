module BrabusStress
  module Steps
    class Map
    
    end
  end
end