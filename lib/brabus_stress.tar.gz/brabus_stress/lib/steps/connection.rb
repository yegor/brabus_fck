require 'socket'

module BrabusStress
  module Steps
    class Connection
      attr_accessor :socket
      
      def connect
        @socket = TCPSocket.new @config[:host], @config[:port]
      end
    
    end
  end
end