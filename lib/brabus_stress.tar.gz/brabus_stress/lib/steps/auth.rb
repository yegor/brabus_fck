module BrabusStress
  module Steps
    class Auth
    
    end
  end
end