module BrabusStress
  module Scenarios
    class Location
      
      def self.run!
        @runner = BrabusStress::BenchmarkProxy.new(BrabusStress::Runner.new, self)
        
        @runner.connect!
        @runner.balance
        @runner.signup_and_login
        @runner.sync_delta
        
        BrabusStress::LOOP_COUNT.times do |i| 
          @runner.location
        end
        
        @runner.logout
      end

    end
  end
end