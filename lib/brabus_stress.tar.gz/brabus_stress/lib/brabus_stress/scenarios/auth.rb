module BrabusStress
  module Scenarios
    class Auth
      
      def self.run!
        15.times {
          @runner = BrabusStress::BenchmarkProxy.new(BrabusStress::Runner.new, self)          
          @runner.connect!
          @runner.balance
          @runner.signup_and_login
          @runner.sync_delta
          @runner.logout
        }
      end

    end
  end
end