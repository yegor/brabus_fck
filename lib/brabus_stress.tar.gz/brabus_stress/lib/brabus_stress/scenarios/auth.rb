module BrabusStress
  module Scenarios
    class Auth
      
      def self.run!
        (BrabusStress::LOOP_COUNT / 5).to_i.times {
          @runner = BrabusStress::BenchmarkProxy.new(BrabusStress::Runner.new, self)          
          @runner.connect!
          @runner.balance
          @runner.signup_and_login
          @runner.sync_delta
          @runner.logout
        }
      end

    end
  end
end