module BrabusStress
  module Scenarios
    class Geocode
      
      def self.run!
        @runner = BrabusStress::BenchmarkProxy.new(BrabusStress::Runner.new, self)
        
        @runner.connect!
        @runner.balance
        @runner.signup_and_login
        @runner.sync_delta
        
        100.times { |i|
          @runner.geocode_direct(i)
        }
        
        @runner.logout
      end

    end
  end
end